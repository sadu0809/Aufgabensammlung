﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Zahlen zwischen 1 und 30, die durch 5 und/oder 3 ohne Rest teilbar sind");
            for (int i = 1; i < 30; i++)
            {
                if (i % 3 == 0 || i % 5 == 0)
                {
                    
                  Console.Write(i + ", ");
                        
                }
                

            }
            Console.Write("30");
            Console.ReadKey();
        }
    }
}
